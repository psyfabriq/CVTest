
#!/bin/bash
echo "###################################CONFIG IMAGES TO LEARN############################################"
ls $HOME/Documents/CascadeTraining/
read -e -p "Wat we learn  # " -i "invoice" LEARN
cd $HOME/Documents/CascadeTraining/${LEARN}
find Negative -name '*.jpg' > negatives.txt
for file in  $(ls Positive -I '.*png' );
do
echo $file
POSDATA=`identify -format "Positive/%f 1 0 0 %w %h" Positive/$file`
echo $POSDATA >> positives.dat
done
echo "###################################CONFIG POSITIVE FILE############################################"

read -e -p "Enter width (MAX 100):" -i "100" WIDTH
read -e -p "Enter height (MAX 100):" -i "100" HEIGHT

CPOSITIVE="$(find Positive -type f  -printf x -name '*.png' | wc -c)"
CNEGATIVE="$(find Negative -type f  -printf x -name '*.jpg' | wc -c)"

echo "Number of positive files: " ${CPOSITIVE}
echo "Number of negative files: " ${CNEGATIVE}

if [ $CPOSITIVE > 0 ] && [ $CNEGATIVE > 0 ]; then
    opencv_createsamples -info positives.dat -num ${CPOSITIVE} -vec samples_out.vec -w ${WIDTH} -h ${HEIGHT}
    echo "###################################LEARN CASCADE############################################"
    read -e -p "Enter number stage (10~20):" -i "20" NUMSTAGES
    read -e -p "Enter minimal hit rate  (0.999):" -i "0.999" MINHITRATE
    read -e -p "Enter maximum false alarm rate (0.5):" -i "0.5" MAXFALSEALARMRATE
    read -e -p "Enter half of ram memory (1024):" -i "1024" RAMMEMORY
    read -e -p "Enter width (MAX 100):" -i "24" WIDTH
    read -e -p "Enter height (MAX 100):" -i "24" HEIGHT

    opencv_traincascade -data Training/ -vec samples_out.vec -bg negatives.txt -numStages ${NUMSTAGES} -minHitRate ${MINHITRATE} -maxFalseAlarmRate ${MAXFALSEALARMRATE} -numPos ${CPOSITIVE} -numNeg ${CNEGATIVE} -w ${WIDTH} -h ${HEIGHT} -mode ALL -precalcValBufSize ${RAMMEMORY} -precalcIdxBufSize ${RAMMEMORY}

else
    echo "**** No positive or negative files found ****"
fi
